# 📚 PRO-MARK 
## 📑Mark Your Attendance In One Click
The web application is completetly developed in python. Python Flask is used as the web framework for developing.

### Database used
 - MongoDB 
 - https://www.mongodb.com/try/download/community

### Requirements
 - Upload your training images in the samples directory
 - Run app.py
